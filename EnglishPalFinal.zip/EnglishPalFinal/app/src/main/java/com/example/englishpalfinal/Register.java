package com.example.englishpalfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    EditText userName, email, password;
    Button register, sendToLogin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        userName =  findViewById(R.id.userNameRegister);
        email =  findViewById(R.id.emailRegister);
        password = findViewById(R.id.passwordRegister);
        register = findViewById(R.id.buttonRegister);
        sendToLogin = findViewById(R.id.buttonSendToLogin);
        DB = new DBHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = userName.getText().toString();
                String pass = password.getText().toString();
                String em = email.getText().toString();

                if (user.equals("") || pass.equals("") || em.equals("")){
                    Toast.makeText(Register.this,"Please Enter All The Info!",Toast.LENGTH_SHORT).show();
                } else{
                    Boolean checkUser = DB.checkUserName(user);
                    if (checkUser == false){
                        Boolean insert = DB.insertData(user, pass, em);
                        if (insert == true){
                            Toast.makeText(Register.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Login.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(Register.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Register.this, "User Already Exists! You Can Log In!", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        sendToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
            }
        });
    }
}